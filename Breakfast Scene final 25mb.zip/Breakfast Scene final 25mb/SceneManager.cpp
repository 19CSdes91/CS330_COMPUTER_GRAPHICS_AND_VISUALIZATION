///////////////////////////////////////////////////////////////////////////////
// shadermanager.cpp
// ============
// manage the loading and rendering of 3D scenes
//
//  AUTHOR: Brian Battersby - SNHU Instructor / Computer Science
//	Created for CS-330-Computational Graphics and Visualization, Nov. 1st, 2023
// 
// UPDATED BY: Destinee Herrera
// CS-330-Computational Graphics and Visualization
// DUE:10/11/2026
// 
// SOURCES:
// Rideout, P. (n.d.). Philip Rideout?:: Colors. https://web.archive.org/web/20100429175700/http://prideout.net/archive/colors.php
///////////////////////////////////////////////////////////////////////////////

#include "SceneManager.h"

#ifndef STB_IMAGE_IMPLEMENTATION
#define STB_IMAGE_IMPLEMENTATION
#include "stb_image.h"
#endif

#include <glm/gtx/transform.hpp>

// declaration of global variables
namespace
{
	const char* g_ModelName = "model";
	const char* g_ColorValueName = "objectColor";
	const char* g_TextureValueName = "objectTexture";
	const char* g_UseTextureName = "bUseTexture";
	const char* g_UseLightingName = "bUseLighting";
}

/***********************************************************
 *  SceneManager()
 *
 *  The constructor for the class
 ***********************************************************/
SceneManager::SceneManager(ShaderManager *pShaderManager)
{
	m_pShaderManager = pShaderManager;
	m_basicMeshes = new ShapeMeshes();
}

/***********************************************************
 *  ~SceneManager()
 *
 *  The destructor for the class
 ***********************************************************/
SceneManager::~SceneManager()
{
	m_pShaderManager = NULL;
	delete m_basicMeshes;
	m_basicMeshes = NULL;
}

/***********************************************************
 *  CreateGLTexture()
 *
 *  This method is used for loading textures from image files,
 *  configuring the texture mapping parameters in OpenGL,
 *  generating the mipmaps, and loading the read texture into
 *  the next available texture slot in memory.
 ***********************************************************/
bool SceneManager::CreateGLTexture(const char* filename, std::string tag)
{
	int width = 0;
	int height = 0;
	int colorChannels = 0;
	GLuint textureID = 0;

	// indicate to always flip images vertically when loaded
	stbi_set_flip_vertically_on_load(true);

	// try to parse the image data from the specified image file
	unsigned char* image = stbi_load(
		filename,
		&width,
		&height,
		&colorChannels,
		0);

	// if the image was successfully read from the image file
	if (image)
	{
		std::cout << "Successfully loaded image:" << filename << ", width:" << width << ", height:" << height << ", channels:" << colorChannels << std::endl;

		glGenTextures(1, &textureID);
		glBindTexture(GL_TEXTURE_2D, textureID);

		// set the texture wrapping parameters
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
		// set texture filtering parameters
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

		// if the loaded image is in RGB format
		if (colorChannels == 3)
			glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB8, width, height, 0, GL_RGB, GL_UNSIGNED_BYTE, image);
		// if the loaded image is in RGBA format - it supports transparency
		else if (colorChannels == 4)
			glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA8, width, height, 0, GL_RGBA, GL_UNSIGNED_BYTE, image);
		else
		{
			std::cout << "Not implemented to handle image with " << colorChannels << " channels" << std::endl;
			return false;
		}

		// generate the texture mipmaps for mapping textures to lower resolutions
		glGenerateMipmap(GL_TEXTURE_2D);

		// free the image data from local memory
		stbi_image_free(image);
		glBindTexture(GL_TEXTURE_2D, 0); // Unbind the texture

		// register the loaded texture and associate it with the special tag string
		m_textureIDs[m_loadedTextures].ID = textureID;
		m_textureIDs[m_loadedTextures].tag = tag;
		m_loadedTextures++;

		return true;
	}

	std::cout << "Could not load image:" << filename << std::endl;

	// Error loading the image
	return false;
}

/***********************************************************
 *  BindGLTextures()
 *
 *  This method is used for binding the loaded textures to
 *  OpenGL texture memory slots.  There are up to 16 slots.
 ***********************************************************/
void SceneManager::BindGLTextures()
{
	for (int i = 0; i < m_loadedTextures; i++)
	{
		// bind textures on corresponding texture units
		glActiveTexture(GL_TEXTURE0 + i);
		glBindTexture(GL_TEXTURE_2D, m_textureIDs[i].ID);
	}
}

/***********************************************************
 *  DestroyGLTextures()
 *
 *  This method is used for freeing the memory in all the
 *  used texture memory slots.
 ***********************************************************/
void SceneManager::DestroyGLTextures()
{
	for (int i = 0; i < m_loadedTextures; i++)
	{
		glGenTextures(1, &m_textureIDs[i].ID);
	}
}

/***********************************************************
 *  FindTextureID()
 *
 *  This method is used for getting an ID for the previously
 *  loaded texture bitmap associated with the passed in tag.
 ***********************************************************/
int SceneManager::FindTextureID(std::string tag)
{
	int textureID = -1;
	int index = 0;
	bool bFound = false;

	while ((index < m_loadedTextures) && (bFound == false))
	{
		if (m_textureIDs[index].tag.compare(tag) == 0)
		{
			textureID = m_textureIDs[index].ID;
			bFound = true;
		}
		else
			index++;
	}

	return(textureID);
}

/***********************************************************
 *  FindTextureSlot()
 *
 *  This method is used for getting a slot index for the previously
 *  loaded texture bitmap associated with the passed in tag.
 ***********************************************************/
int SceneManager::FindTextureSlot(std::string tag)
{
	int textureSlot = -1;
	int index = 0;
	bool bFound = false;

	while ((index < m_loadedTextures) && (bFound == false))
	{
		if (m_textureIDs[index].tag.compare(tag) == 0)
		{
			textureSlot = index;
			bFound = true;
		}
		else
			index++;
	}

	return(textureSlot);
}

/***********************************************************
 *  FindMaterial()
 *
 *  This method is used for getting a material from the previously
 *  defined materials list that is associated with the passed in tag.
 ***********************************************************/
bool SceneManager::FindMaterial(std::string tag, OBJECT_MATERIAL& material)
{
	if (m_objectMaterials.size() == 0)
	{
		return(false);
	}

	int index = 0;
	bool bFound = false;
	while ((index < m_objectMaterials.size()) && (bFound == false))
	{
		if (m_objectMaterials[index].tag.compare(tag) == 0)
		{
			bFound = true;
			material.ambientColor = m_objectMaterials[index].ambientColor;
			material.ambientStrength = m_objectMaterials[index].ambientStrength;
			material.diffuseColor = m_objectMaterials[index].diffuseColor;
			material.specularColor = m_objectMaterials[index].specularColor;
			material.shininess = m_objectMaterials[index].shininess;
		}
		else
		{
			index++;
		}
	}

	return(true);
}

/***********************************************************
 *  SetTransformations()
 *
 *  This method is used for setting the transform buffer
 *  using the passed in transformation values.
 ***********************************************************/
void SceneManager::SetTransformations(
	glm::vec3 scaleXYZ,
	float XrotationDegrees,
	float YrotationDegrees,
	float ZrotationDegrees,
	glm::vec3 positionXYZ)
{
	// variables for this method
	glm::mat4 modelView;
	glm::mat4 scale;
	glm::mat4 rotationX;
	glm::mat4 rotationY;
	glm::mat4 rotationZ;
	glm::mat4 translation;

	// set the scale value in the transform buffer
	scale = glm::scale(scaleXYZ);
	// set the rotation values in the transform buffer
	rotationX = glm::rotate(glm::radians(XrotationDegrees), glm::vec3(1.0f, 0.0f, 0.0f));
	rotationY = glm::rotate(glm::radians(YrotationDegrees), glm::vec3(0.0f, 1.0f, 0.0f));
	rotationZ = glm::rotate(glm::radians(ZrotationDegrees), glm::vec3(0.0f, 0.0f, 1.0f));
	// set the translation value in the transform buffer
	translation = glm::translate(positionXYZ);

	modelView = translation * rotationX * rotationY * rotationZ * scale;

	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setMat4Value(g_ModelName, modelView);
	}
}

/***********************************************************
 *  SetShaderColor()
 *
 *  This method is used for setting the passed in color
 *  into the shader for the next draw command
 ***********************************************************/
void SceneManager::SetShaderColor(
	float redColorValue,
	float greenColorValue,
	float blueColorValue,
	float alphaValue)
{
	// variables for this method
	glm::vec4 currentColor;

	currentColor.r = redColorValue;
	currentColor.g = greenColorValue;
	currentColor.b = blueColorValue;
	currentColor.a = alphaValue;

	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setIntValue(g_UseTextureName, false);
		m_pShaderManager->setVec4Value(g_ColorValueName, currentColor);
	}
}

/***********************************************************
 *  SetShaderTexture()
 *
 *  This method is used for setting the texture data
 *  associated with the passed in ID into the shader.
 ***********************************************************/
void SceneManager::SetShaderTexture(
	std::string textureTag)
{
	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setIntValue(g_UseTextureName, true);

		int textureID = -1;
		textureID = FindTextureSlot(textureTag);
		m_pShaderManager->setSampler2DValue(g_TextureValueName, textureID);
	}
}

/***********************************************************
 *  SetTextureUVScale()
 *
 *  This method is used for setting the texture UV scale
 *  values into the shader.
 ***********************************************************/
void SceneManager::SetTextureUVScale(float u, float v)
{
	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setVec2Value("UVscale", glm::vec2(u, v));
	}
}

/***********************************************************
 *  SetShaderMaterial()
 *
 *  This method is used for passing the material values
 *  into the shader.
 ***********************************************************/
void SceneManager::SetShaderMaterial(
	std::string materialTag)
{
	if (m_objectMaterials.size() > 0)
	{
		OBJECT_MATERIAL material;
		bool bReturn = false;

		bReturn = FindMaterial(materialTag, material);
		if (bReturn == true)
		{
			m_pShaderManager->setVec3Value("material.ambientColor", material.ambientColor);
			m_pShaderManager->setFloatValue("material.ambientStrength", material.ambientStrength);
			m_pShaderManager->setVec3Value("material.diffuseColor", material.diffuseColor);
			m_pShaderManager->setVec3Value("material.specularColor", material.specularColor);
			m_pShaderManager->setFloatValue("material.shininess", material.shininess);
		}
	}
}

/**************************************************************/
/*** STUDENTS CAN MODIFY the code in the methods BELOW for  ***/
/*** preparing and rendering their own 3D replicated scenes.***/
/*** Please refer to the code in the OpenGL sample project  ***/
/*** for assistance.                                        ***/
/**************************************************************/
// ********************************************************
// PREPARE SCENE
// Loads shapes, textures, materials, and lighting.
// ********************************************************


 
void SceneManager::PrepareScene()
{
	// only one instance of a particular mesh needs to be
	// loaded in memory no matter how many times it is drawn
	// in the rendered 3D scene

	m_basicMeshes->LoadPlaneMesh();

	//>>LOAD BOX MESH<<
	m_basicMeshes->LoadBoxMesh();

	//>>LOAD CYLINDER MESH<<
	m_basicMeshes->LoadCylinderMesh();

	//>>LOAD SPHERE MESH<<
	m_basicMeshes->LoadSphereMesh();

	//>>LOAD TORUS MESH<<
	m_basicMeshes->LoadTorusMesh();

	/***********************************************************
  *  LoadSceneTextures()
  *
  *  This method is used for preparing the 3D scene by loading
  *  the shapes, textures in memory to support the 3D scene
  *  rendering
  ***********************************************************/

	/************LOAD TEXTURE*******************/

	//Load Table texture
	CreateGLTexture("C:\\Users\\dessy\\OneDrive\\Pictures\\Screenshots\\CS330Content\\Projects\\7-1_FinalProjectMilestones\\Source\\table.jpg", "tableTexture");

	//load pancake texture
	CreateGLTexture("C:\\Users\\dessy\\OneDrive\\Pictures\\Screenshots\\CS330Content\\Projects\\7-1_FinalProjectMilestones\\Source\\pancake.png", "pancakeTexture");

	//Load front facing blueberry texture
	CreateGLTexture("C:\\Users\\dessy\\OneDrive\\Pictures\\Screenshots\\CS330Content\\Projects\\7-1_FinalProjectMilestones\\Source\\blueberryf.png", "blueberryfTexture");

	// load Syrup texture
	CreateGLTexture("C:\\Users\\dessy\\OneDrive\\Pictures\\Screenshots\\CS330Content\\Projects\\7-1_FinalProjectMilestones\\Source\\maplesyrup.png", "syrupTexture");

	//load glass texture
	// load Syrup texture
	CreateGLTexture("C:\\Users\\dessy\\OneDrive\\Pictures\\Screenshots\\CS330Content\\Projects\\7-1_FinalProjectMilestones\\Source\\glass.png", "glassTexture");

	//Load bowl of blueberries
	CreateGLTexture("C:\\Users\\dessy\\OneDrive\\Pictures\\Screenshots\\CS330Content\\Projects\\7-1_FinalProjectMilestones\\Source\\blueberries.png", "blueberriesTexture");



	//Bind Texture
	BindGLTextures();

	//set up materials 
	DefineObjectMaterials();

	//set up lighting
	SetupSceneLights();

}

/***********************LOAD LIGHTING************************************
 *  DefineObjectMaterials()
 *
 *  This method is used for configuring the various material
 *  settings for all of the objects within the 3D scene.
 ***********************************************************/
void SceneManager::DefineObjectMaterials()
{
OBJECT_MATERIAL glassMaterial;
	glassMaterial.ambientColor = glm::vec3(0.7f, 0.85f, 0.9f);
	glassMaterial.ambientStrength = 0.1f;
	glassMaterial.diffuseColor = glm::vec3(0.69f, 0.878f, 0.902f);
	glassMaterial.specularColor = glm::vec3(0.8f, 0.8f, 0.8f);
	glassMaterial.shininess = 128.0;
	glassMaterial.tag = "glass";

	m_objectMaterials.push_back(glassMaterial);

	OBJECT_MATERIAL tableMaterial;
	tableMaterial.ambientColor = glm::vec3(0.5f, 0.5f, 0.5f);
	tableMaterial.ambientStrength = 0.3f;
	tableMaterial.diffuseColor = glm::vec3(0.8f, 0.8f, 0.8f);
	tableMaterial.specularColor = glm::vec3(0.3f, 0.3f, 0.3f);
	tableMaterial.shininess = 8.0;
	tableMaterial.tag = "table";

	m_objectMaterials.push_back(tableMaterial);

	OBJECT_MATERIAL matteMaterial;
	matteMaterial.ambientColor = glm::vec3(0.2f, 0.2f, 0.2f);
	matteMaterial.ambientStrength = 0.4f;
	matteMaterial.diffuseColor = glm::vec3(0.8f, 0.8f, 0.8f);
	matteMaterial.specularColor = glm::vec3(0.1f, 0.1f, 0.1f);
	matteMaterial.shininess = 2.0;
	matteMaterial.tag = "matte";
	m_objectMaterials.push_back(matteMaterial);


	}

	

/***********************************************************
 *  SetupSceneLights()
 *
 *  This method is called to add and configure the light
 *  sources for the 3D scene.  There are up to 4 light sources.
 ***********************************************************/
void SceneManager::SetupSceneLights()
{
	// this line of code is NEEDED for telling the shaders to render 
	// the 3D scene with custom lighting - to use the default rendered 
	// lighting then comment out the following line
	m_pShaderManager->setBoolValue(g_UseLightingName, true);

	//warm light for scene
	m_pShaderManager->setVec3Value("lightSources[0].position", 0.35f, 0.33f, 0.30f);
	m_pShaderManager->setVec3Value("lightSources[0].ambientColor", 0.6f, 0.6f, 0.6f);
	m_pShaderManager->setVec3Value("lightSources[0].diffuseColor", 1.0f, 0.9f, 0.80f);
	m_pShaderManager->setVec3Value("lightSources[0].specularColor", 1.0f, 1.0f, 1.0f);
	m_pShaderManager->setFloatValue("lightSources[0].focalStrength", 32.0f);
	m_pShaderManager->setFloatValue("lightSources[0].specularIntensity", 1.0f);

	//light2 left light
		m_pShaderManager->setVec3Value("lightSources[1].position", .12f, 0.12f, 0.15f);
		m_pShaderManager->setVec3Value("lightSources[1].ambientColor", 0.1f, 0.1f, 0.15f);
		m_pShaderManager->setVec3Value("lightSources[1].diffuseColor", 0.3f, 0.3f, 0.35f);
		m_pShaderManager->setVec3Value("lightSources[1].specularColor", 0.1f, 0.1f, 0.1f);
		m_pShaderManager->setFloatValue("lightSources[1].focalStrength", 16.0f);
		m_pShaderManager->setFloatValue("lightSources[1].specularIntensity", 0.2f);
		
		// light 3 Back light
		m_pShaderManager->setVec3Value("lightSources[2].position", 0.10f, 0.10f, 0.13f);
		m_pShaderManager->setVec3Value("lightSources[2].ambientColor", 0.02f, 0.02f, 0.02f);
		m_pShaderManager->setVec3Value("lightSources[2].diffuseColor", 0.20f, 0.20f, 0.25f);
		m_pShaderManager->setVec3Value("lightSources[2].specularColor", 0.3f, 0.3f, 0.3f);
		m_pShaderManager->setFloatValue("lightSources[2].focalStrength", 32.0f);
		m_pShaderManager->setFloatValue("lightSources[2].specularIntensity", 0.08f);

		// light 4 Front fill light
		m_pShaderManager->setVec3Value("lightSources[3].position", 0.07f, 0.07f, 0.07f);
		m_pShaderManager->setVec3Value("lightSources[3].ambientColor", 0.02f, 0.02f, 0.02f);
		m_pShaderManager->setVec3Value("lightSources[3].diffuseColor", 0.15f, 0.15f, 0.15f);
		m_pShaderManager->setVec3Value("lightSources[3].specularColor", 0.2f, 0.2f, 0.2f);
		m_pShaderManager->setFloatValue("lightSources[3].focalStrength", 32.0f);
		m_pShaderManager->setFloatValue("lightSources[3].specularIntensity", 0.05f);
	}




/***********************************************************
 *  RenderScene()
 *
 *  This method is used for rendering the 3D scene by 
 *  transforming and drawing the basic 3D shapes
 ***********************************************************/
void SceneManager::RenderScene()
{
	// declare the variables for the transformations
	glm::vec3 scaleXYZ;
	float XrotationDegrees = 0.0f;
	float YrotationDegrees = 0.0f;
	float ZrotationDegrees = 0.0f;
	glm::vec3 positionXYZ;

	//keep lighting off
	//m_pShaderManager->setBoolValue(g_UseLightingName, false);

	/*** Set needed transformations before drawing the basic mesh.  ***/
	/*** This same ordering of code should be used for transforming ***/
	/*** and drawing all the basic 3D shapes.						***/

	/********************TABLE**********************************************/
	// set the XYZ scale for the mesh
	// 
	//BOTTOM PLANE
	//COLOR:STEEL BLUE.
	scaleXYZ = glm::vec3(20.0f, 1.0f, 10.0f);

	// set the XYZ rotation for the mesh
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	// set the XYZ position for the mesh
	positionXYZ = glm::vec3(0.0f, 0.0f, 0.0f);

	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	//SetShaderColor(0.275, 0.510, 0.706, 1);
	
	//turn on light 
	//m_pShaderManager->setBoolValue(g_UseLightingName, true);

	//Set the table texture
	SetShaderTexture("tableTexture");
	

	//set glass material
	SetShaderMaterial("table");


	//Scale tile for the large plane
	SetTextureUVScale(4.0f, 4.0f);

	// draw the mesh with transformation values
	m_basicMeshes->DrawPlaneMesh();

	//turn it off
	//m_pShaderManager->setBoolValue(g_UseLightingName, false);
	/****************************************************************/


	/*********************PLATE/TRAY************************************/
	// set the XYZ scale for the mesh
	// 
	//BREAKFAST TRAY
	//COLOR: ALICE BLUE
	//***The plate will sit underneath holding everything 
	scaleXYZ = glm::vec3(10.0f, 0.2f, 3.0f);

	// set the XYZ rotation for the mesh
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	// set the XYZ position for the mesh
	positionXYZ = glm::vec3(1.5f, 0.1f, 7.3f);

	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	SetShaderColor(0.941, 0.973, 1.000, 1);
	//apply matte
	SetShaderMaterial("matte");

	// draw the mesh with transformation values
	m_basicMeshes->DrawBoxMesh();
	/****************************************************************/

	/*********************MAPLE SYRUP PITCHER- HANDLE************************************/
	// set the XYZ scale for the mesh
	// 
	//HANDLE
	//TEXTURE: SYRUP
	
	scaleXYZ = glm::vec3(1.0f, 1.3f, 1.3f);

	// set the XYZ rotation for the mesh
	XrotationDegrees = 0.0f;
	YrotationDegrees = -20.0f;
	ZrotationDegrees = -90.0f;

	// set the XYZ position for the mesh
	positionXYZ = glm::vec3(7.0f, 2.2f, 4.2f);

	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	//SetShaderColor(0.8, 0.9, 0.95, 0.6);

	SetShaderColor(1.0, 1.0, 1.0, 1.0);

	//Set the glass texture
	SetShaderTexture("glassTexture");

	//Scale tile 
	SetTextureUVScale(1.0f, 1.0f);

	//apply glass
	SetShaderMaterial("glass");
	// draw the mesh with transformation values
	m_basicMeshes->DrawTorusMesh();
	/****************************************************************/

	/*********************MAPLE SYRUP PITCHER BODY************************************/
	// set the XYZ scale for the mesh
	// 
	//PITCHER
	//	TEXTUR: SYRUP
	
	scaleXYZ = glm::vec3(1.7f, 4.0f, 1.0f);

	// set the XYZ rotation for the mesh
	XrotationDegrees =-0.5f;
	YrotationDegrees = -2.0f;
	ZrotationDegrees = 2.0f;

	// set the XYZ position for the mesh
	positionXYZ = glm::vec3(5.5f, 0.08f, 4.2f);

	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	//SetShaderColor(0.8, 0.9, 0.95, 0.8);
	//Set the pancake texture
	SetShaderTexture("syrupTexture");

	//Scale tile 
	SetTextureUVScale(1.0f, 1.0f);

	//apply glass
	SetShaderMaterial("glass");

	// draw the mesh with transformation values
	m_basicMeshes->DrawCylinderMesh();
	/****************************************************************/

	/*********************BLUEBERRY BOWL************************************/
	// set the XYZ scale for the mesh
	// 
	//COLOR: POWDER BLUE
	
	scaleXYZ = glm::vec3(2.0f, 0.7f, 1.0f);

	// set the XYZ rotation for the mesh
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	// set the XYZ position for the mesh
	positionXYZ = glm::vec3(3.5f, 0.2f, 7.4f);

	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	
	// Turn texture OFF so the bowl uses color instead of a leftover texture.
m_pShaderManager->setBoolValue(g_UseTextureName, false);

// Set the bowl color.
SetShaderColor(0.690f, 0.878f, 0.902f, 1.0f);

// Turn lighting ON for the bowl.
//m_pShaderManager->setBoolValue(g_UseLightingName, true);

// Apply the glass material.
SetShaderMaterial("glass");
// Turn lighting OFF after drawing.
//m_pShaderManager->setBoolValue(g_UseLightingName, false);

// Draw the bowl.
m_basicMeshes->DrawCylinderMesh();


	
	/****************************************************************/

	/*********************PANCAKES************************************/
	// set the XYZ scale for the mesh
	// 
	//TEXTURE: Pancake.png
	/// created using Krita
 
	


	scaleXYZ = glm::vec3(1.8f, 2.5f, 1.7f);

	// set the XYZ rotation for the mesh
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	// set the XYZ position for the mesh
	positionXYZ = glm::vec3(-1.0f, 0.1f, 7.0f);

	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	//SetShaderColor(0.690, 0.878, 0.902, 1.0);
	
	
	//Set the pancake texture
	SetShaderTexture("pancakeTexture");

	


	//Scale tile 
	SetTextureUVScale(1.0f, 1.0f);

	// Apply material
	SetShaderMaterial("matte");

	// draw the mesh with transformation values
	m_basicMeshes->DrawCylinderMesh();

	

	/*********************BUTTER************************************/

	// set the XYZ scale for the mesh
	// 
	//COLOR: LIGHTGOLDENRODYELLOW

	scaleXYZ = glm::vec3(1.1f, 0.3f, 1.0f);

	// set the XYZ rotation for the mesh
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	// set the XYZ position for the mesh
	positionXYZ = glm::vec3(-1.5f, 2.6f, 7.4f);

	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	SetShaderColor(0.980, 0.980, 0.824, 1.0);
	//apply matte
	SetShaderMaterial("matte");

	// draw the mesh with transformation values
	m_basicMeshes->DrawBoxMesh();

	/*********************BLUEBERRIES--ON PANCAKE************************************/

	// set the XYZ scale for the mesh
	// 
	//TEXTURE:BLUEBERRYf

	//blueberry 1 
	scaleXYZ = glm::vec3(0.25f, 0.25f, 0.25f);


	// set the XYZ rotation for the mesh
	XrotationDegrees = 25.0f;
	YrotationDegrees =0.0f;
	ZrotationDegrees = -45.0f;

	// set the XYZ position for the mesh
	positionXYZ = glm::vec3(-0.9f, 2.85f, 7.4f);

	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	//SetShaderColor(0.980, 0.980, 0.824, 1.0);

	

	
	//Set the pancake texture
	SetShaderTexture("blueberryfTexture");

	//Scale tile 
	SetTextureUVScale(1.0f, 1.0f);

	//apply matte
	SetShaderMaterial("matte");

	// draw the mesh with transformation values
	m_basicMeshes->DrawSphereMesh();

	//blueberry 2
	scaleXYZ = glm::vec3(0.25f, 0.25f, 0.25f);


	// set the XYZ rotation for the mesh
	XrotationDegrees = 25.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = -45.0f;

	// set the XYZ position for the mesh
	positionXYZ = glm::vec3(0.3f, 2.8f, 7.76f);

	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	//SetShaderColor(0.980, 0.980, 0.824, 1.0);




	//Set the pancake texture
	SetShaderTexture("blueberryfTexture");

	//Scale tile 
	SetTextureUVScale(1.0f, 1.0f);
	//apply matte
	SetShaderMaterial("matte");

	// draw the mesh with transformation values
	m_basicMeshes->DrawSphereMesh();

	//blueberry 3
	scaleXYZ = glm::vec3(0.23f, 0.23f, 0.23f);


	// set the XYZ rotation for the mesh
	XrotationDegrees = 30.0f;
	YrotationDegrees = -30.0f;
	ZrotationDegrees = -45.0f;

	// set the XYZ position for the mesh
	positionXYZ = glm::vec3(-0.75f, 2.8f, 7.8f);

	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	//SetShaderColor(0.980, 0.980, 0.824, 1.0);




	//Set the pancake texture
	SetShaderTexture("blueberryfTexture");

	//Scale tile 
	SetTextureUVScale(1.0f, 1.0f);

	//apply matte
	SetShaderMaterial("matte");

	// draw the mesh with transformation values
	m_basicMeshes->DrawSphereMesh();

	//blueberry 4
	scaleXYZ = glm::vec3(0.23f, 0.23f, 0.23f);


	// set the XYZ rotation for the mesh
	XrotationDegrees = 60.0f;
	YrotationDegrees = 10.0f;
	ZrotationDegrees = -35.0f;

	// set the XYZ position for the mesh
	positionXYZ = glm::vec3(-0.55f, 2.8f, 7.2f);

	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	//SetShaderColor(0.980, 0.980, 0.824, 1.0);




	//Set the pancake texture
	SetShaderTexture("blueberryfTexture");

	//Scale tile 
	SetTextureUVScale(1.0f, 1.0f);

	//apply matte
	SetShaderMaterial("matte");

	// draw the mesh with transformation values
	m_basicMeshes->DrawSphereMesh();

	/*********************BLUEBERRTIES IN BOWL************************************/
// set the XYZ scale for the mesh
// 
//TEXTURE:Blueberries.png
/// created using Krita




	scaleXYZ = glm::vec3(1.3f, 1.5f, 0.8f);

	// set the XYZ rotation for the mesh
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 90.0f;

	// set the XYZ position for the mesh
	positionXYZ = glm::vec3(3.3f, 1.0f, 7.3f);

	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	//SetShaderColor(0.690, 0.878, 0.902, 1.0);


	//Set the pancake texture
	SetShaderTexture("blueberriesTexture");




	//Scale tile 
	SetTextureUVScale(2.0f, 1.0f);

	// Apply material
	SetShaderMaterial("matte");

	// draw the mesh with transformation values
	m_basicMeshes->DrawSphereMesh();


}


